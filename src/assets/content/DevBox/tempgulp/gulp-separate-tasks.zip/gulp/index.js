require('./tasks/build');
require('./tasks/styles');
require('./tasks/scripts');
require('./tasks/images');
require('./tasks/html');
require('./tasks/watch');
require('./tasks/default');
