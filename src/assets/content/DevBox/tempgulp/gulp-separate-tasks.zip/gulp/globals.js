var globals = {
  appPath: './app',
  distPath: './dist',

  
    wrapper: '{,*/}*.html'
  
};

module.exports = globals;
